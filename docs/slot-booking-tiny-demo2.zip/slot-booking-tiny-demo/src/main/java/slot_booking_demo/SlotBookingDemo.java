package slot_booking_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlotBookingDemo {
    public static void main(String[] args) {
        SpringApplication.run(SlotBookingDemo.class, args);
    }
}
