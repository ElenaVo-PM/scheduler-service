package slot_booking_demo.dto;

import java.time.LocalDateTime;

public class TimeSlot {
    LocalDateTime start;
    LocalDateTime finish;
}
